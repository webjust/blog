<?php
return array(
    'host' => 'localhost',
    'user' => 'root',
    'password' => 'root',
    'db' => 'demo',
    'charset' => 'utf8'
);
