<meta charset="utf-8">
<?php
    include('./lib/init.php');
    include('./view/front/index.html');
?>
