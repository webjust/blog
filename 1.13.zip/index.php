<meta charset="utf-8">
<?php
    include('./view/front/index.html');
?>
